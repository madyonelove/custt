package com.example.homepodcast

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import kotlin.math.sqrt

/** Захват системного звука (PCM 16-bit, 44100 Hz, stereo). */
class CaptureService : Service() {
    companion object {
        const val SAMPLE_RATE = 44100
        /** Сюда в этапе 2 подключим отправку на HomePod. */
        @Volatile var onPcm: ((ByteArray, Int) -> Unit)? = null
        @Volatile var active = false
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startForegroundNotification()
        val code = intent!!.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { Logger.log("Проекция остановлена системой"); stopSelf() }
            }, null)
        }
        startCapture()
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "Capture", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap")
            .setContentTitle("HomePodCast")
            .setContentText("Захват звука активен")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture() {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val rec = try {
            AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
                .setBufferSizeInBytes(SAMPLE_RATE * 4).build()
        } catch (e: Exception) {
            Logger.log("Ошибка AudioRecord: $e"); stopSelf(); return
        }
        record = rec
        rec.startRecording()
        running = true
        active = true
        Logger.log("Захват звука запущен")
        Thread {
            // 352 кадра * 4 байта = размер пакета ALAC/RAOP, пригодится на этапе 2
            val buf = ByteArray(352 * 4)
            var lastLog = 0L
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                onPcm?.invoke(buf, n)
                val now = System.currentTimeMillis()
                if (now - lastLog > 1000) {
                    lastLog = now
                    Logger.log("Уровень звука: ${rms(buf, n)} (0 = тишина или приложение запретило захват)")
                }
            }
        }.start()
    }

    private fun rms(b: ByteArray, n: Int): Int {
        var sum = 0.0
        var i = 0
        while (i + 1 < n) {
            val s = (b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)
            sum += (s.toShort().toInt()).toDouble().let { it * it }
            i += 2
        }
        return sqrt(sum / (n / 2)).toInt()
    }

    override fun onDestroy() {
        running = false
        active = false
        record?.run { try { stop() } catch (_: Exception) {}; release() }
        projection?.stop()
        Logger.log("Захват остановлен")
        super.onDestroy()
    }
}
