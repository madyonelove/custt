package com.example.homepodcast

import android.os.Handler
import android.os.Looper

object Logger {
    @Volatile var sink: ((String) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    fun log(msg: String) {
        android.util.Log.d("HomePodCast", msg)
        main.post { sink?.invoke(msg) }
    }
}
