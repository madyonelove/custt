package com.example.homepodcast

import org.bouncycastle.crypto.agreement.srp.SRP6StandardGroups
import java.io.*
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Этап 2a: transient pair-setup (SRP-6a, PIN 3939) + зашифрованный RTSP.
 * Цель: убедиться, что HomePod принимает нас и отвечает на зашифрованный OPTIONS.
 */
object RaopProbe {
    fun run(host: String, port: Int) {
        Thread {
            try {
                Session(host, port).use { it.go() }
            } catch (e: Exception) {
                Logger.log("Ошибка: $e")
                android.util.Log.e("HomePodCast", "probe", e)
            }
        }.start()
    }
}

private class Session(val host: String, val port: Int) : Closeable {
    private val sock = Socket()
    private lateinit var inp: InputStream
    private lateinit var out: OutputStream
    private var cseq = 0
    private var wKey: ByteArray? = null
    private var rKey: ByteArray? = null
    private var wCtr = 0L
    private var rCtr = 0L
    private var plain = ByteArray(0)

    override fun close() { try { sock.close() } catch (_: Exception) {} }

    // ---------- TLV8 ----------
    private fun tlv(vararg items: Pair<Int, ByteArray>): ByteArray {
        val o = ByteArrayOutputStream()
        for ((t, v) in items) {
            var i = 0
            while (i < v.size) {
                val n = minOf(255, v.size - i)
                o.write(t); o.write(n); o.write(v, i, n); i += n
            }
        }
        return o.toByteArray()
    }

    private fun parseTlv(b: ByteArray): Map<Int, ByteArray> {
        val m = LinkedHashMap<Int, ByteArray>()
        var i = 0
        while (i + 1 < b.size) {
            val t = b[i].toInt() and 255
            val n = b[i + 1].toInt() and 255
            m[t] = (m[t] ?: ByteArray(0)) + b.copyOfRange(i + 2, i + 2 + n)
            i += 2 + n
        }
        return m
    }

    // ---------- Крипто ----------
    private fun h(vararg p: ByteArray): ByteArray {
        val d = MessageDigest.getInstance("SHA-512")
        p.forEach { d.update(it) }
        return d.digest()
    }
    private fun bytes(x: BigInteger): ByteArray {
        val b = x.toByteArray()
        return if (b.size > 1 && b[0] == 0.toByte()) b.copyOfRange(1, b.size) else b
    }
    private fun pad(x: BigInteger): ByteArray { val b = bytes(x); return ByteArray(384 - b.size) + b }
    private fun xor(a: ByteArray, b: ByteArray) = ByteArray(a.size) { (a[it].toInt() xor b[it].toInt()).toByte() }
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    private fun hmac(key: ByteArray, d: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA512"); m.init(SecretKeySpec(key, "HmacSHA512")); return m.doFinal(d)
    }
    private fun hkdf(ikm: ByteArray, salt: String, info: String): ByteArray {
        val prk = hmac(salt.toByteArray(), ikm)
        return hmac(prk, info.toByteArray() + byteArrayOf(1)).copyOf(32)
    }

    private fun chacha(key: ByteArray, nonce: ByteArray, data: ByteArray, aad: ByteArray, enc: Boolean): ByteArray {
        val c = Cipher.getInstance("ChaCha20/Poly1305/NoPadding")
        c.init(if (enc) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE, SecretKeySpec(key, "ChaCha20"), IvParameterSpec(nonce))
        c.updateAAD(aad)
        return c.doFinal(data)
    }
    private fun nonce(c: Long) = ByteArray(12).also { for (i in 0 until 8) it[4 + i] = (c shr (8 * i)).toByte() }

    // ---------- Транспорт (RTSP, после pair-setup шифруется) ----------
    private fun readRaw(n: Int): ByteArray {
        val b = ByteArray(n); var o = 0
        while (o < n) { val r = inp.read(b, o, n - o); if (r < 0) throw EOFException("соединение закрыто"); o += r }
        return b
    }

    private fun fill() {
        val k = rKey
        if (k == null) {
            val t = ByteArray(4096); val n = inp.read(t)
            if (n < 0) throw EOFException("соединение закрыто")
            plain += t.copyOf(n)
        } else {
            val lb = readRaw(2)
            val len = (lb[0].toInt() and 255) or ((lb[1].toInt() and 255) shl 8)
            plain += chacha(k, nonce(rCtr++), readRaw(len + 16), lb, false)
        }
    }

    private fun write(b: ByteArray) {
        val k = wKey
        if (k == null) out.write(b) else {
            var i = 0
            while (i < b.size) {
                val n = minOf(1024, b.size - i)
                val lb = byteArrayOf(n.toByte(), (n shr 8).toByte())
                out.write(lb)
                out.write(chacha(k, nonce(wCtr++), b.copyOfRange(i, i + n), lb, true))
                i += n
            }
        }
        out.flush()
    }

    private fun send(method: String, uri: String, headers: Map<String, String>, body: ByteArray = ByteArray(0)): Pair<String, ByteArray> {
        val sb = StringBuilder("$method $uri RTSP/1.0\r\nCSeq: ${++cseq}\r\nUser-Agent: AirPlay/320.20\r\n")
        headers.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        if (body.isNotEmpty()) sb.append("Content-Length: ${body.size}\r\n")
        sb.append("\r\n")
        write(sb.toString().toByteArray() + body)

        var i: Int
        while (true) {
            i = String(plain, Charsets.ISO_8859_1).indexOf("\r\n\r\n")
            if (i >= 0) break
            fill()
        }
        val head = String(plain, 0, i, Charsets.ISO_8859_1)
        plain = plain.copyOfRange(i + 4, plain.size)
        val cl = Regex("(?i)content-length:\\s*(\\d+)").find(head)?.groupValues?.get(1)?.toInt() ?: 0
        while (plain.size < cl) fill()
        val resp = plain.copyOf(cl)
        plain = plain.copyOfRange(cl, plain.size)
        return head to resp
    }

    private fun ok(head: String): Boolean {
        val line = head.lineSequence().first()
        if (!line.contains(" 200")) { Logger.log("Отказ колонки:\n$head"); return false }
        return true
    }

    // ---------- Сценарий ----------
    fun go() {
        sock.connect(InetSocketAddress(host, port), 5000)
        sock.soTimeout = 8000
        inp = sock.getInputStream(); out = sock.getOutputStream()
        val hdr = mapOf("Content-Type" to "application/octet-stream", "X-Apple-HKP" to "4")

        Logger.log("Pair-setup: шаг 1")
        var (head, body) = send("POST", "/pair-setup", hdr,
            tlv(0 to byteArrayOf(0), 6 to byteArrayOf(1), 0x13 to byteArrayOf(0x10)))
        if (!ok(head)) return
        val t2 = parseTlv(body)
        t2[7]?.let { Logger.log("Колонка вернула ошибку TLV: ${hex(it)}"); return }
        val salt = t2[2] ?: run { Logger.log("Нет salt: ${hex(body)}"); return }
        val bBytes = t2[3] ?: run { Logger.log("Нет публичного ключа: ${hex(body)}"); return }

        // SRP-6a (3072 бит, SHA-512, логин Pair-Setup, пароль 3939)
        val grp = SRP6StandardGroups.rfc5054_3072
        val n = grp.n; val g = grp.g
        val k = BigInteger(1, h(bytes(n), pad(g)))
        val ab = ByteArray(64).also { SecureRandom().nextBytes(it) }
        val a = BigInteger(1, ab)
        val bigA = g.modPow(a, n)
        val x = BigInteger(1, h(salt, h("Pair-Setup:3939".toByteArray())))
        val bigB = BigInteger(1, bBytes)
        val u = BigInteger(1, h(pad(bigA), pad(bigB)))
        val s = bigB.subtract(k.multiply(g.modPow(x, n))).mod(n).modPow(a.add(u.multiply(x)), n)
        val kSess = h(bytes(s))
        val m1 = h(xor(h(bytes(n)), h(bytes(g))), h("Pair-Setup".toByteArray()), salt, bytes(bigA), bytes(bigB), kSess)

        Logger.log("Pair-setup: шаг 3")
        val r3 = send("POST", "/pair-setup", hdr, tlv(6 to byteArrayOf(3), 3 to pad(bigA), 4 to m1))
        head = r3.first; body = r3.second
        if (!ok(head)) return
        val t4 = parseTlv(body)
        t4[7]?.let { Logger.log("Колонка отклонила пароль/доказательство, TLV-ошибка: ${hex(it)}"); return }
        val m2 = t4[4] ?: run { Logger.log("Нет proof от колонки: ${hex(body)}"); return }
        val expected = h(bytes(bigA), m1, kSess)
        Logger.log("Pair-setup завершён, proof колонки " + if (m2.contentEquals(expected)) "верен ✓" else "НЕ совпал ✗")

        // Включаем шифрование RTSP
        wKey = hkdf(kSess, "Control-Salt", "Control-Write-Encryption-Key")
        rKey = hkdf(kSess, "Control-Salt", "Control-Read-Encryption-Key")
        Logger.log("Шифрование включено, отправляю OPTIONS")
        val r = send("OPTIONS", "*", emptyMap())
        Logger.log("Зашифрованный ответ:\n${r.first}")
    }
}
