package com.example.homepodcast

import com.dd.plist.*
import org.bouncycastle.crypto.agreement.srp.SRP6StandardGroups
import java.io.*
import java.math.BigInteger
import java.net.*
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.PI
import kotlin.math.sin

/**
 * AirPlay 2 стриминг на HomePod (по мотивам pyatv):
 * transient pair-setup -> зашифрованный RTSP -> SETUP x2 -> RECORD -> RTP/UDP (PCM + ChaCha20-Poly1305).
 */
object RaopProbe {
    @Volatile var running = false
    @Volatile private var stopFlag = false

    fun stop() { stopFlag = true }

    fun run(host: String, port: Int, onDone: () -> Unit) {
        if (running) return
        running = true; stopFlag = false
        Thread {
            try {
                Streamer(host, port).use { it.go { stopFlag } }
            } catch (e: Exception) {
                Logger.log("Ошибка: $e")
                android.util.Log.e("HomePodCast", "stream", e)
            } finally {
                running = false
                Logger.log("Стрим завершён")
                onDone()
            }
        }.start()
    }
}

// ---------- Общие крипто-функции ----------
private fun hmac(key: ByteArray, d: ByteArray): ByteArray {
    val m = Mac.getInstance("HmacSHA512"); m.init(SecretKeySpec(key, "HmacSHA512")); return m.doFinal(d)
}
private fun hkdf(ikm: ByteArray, salt: String, info: String): ByteArray =
    hmac(hmac(salt.toByteArray(), ikm), info.toByteArray() + byteArrayOf(1)).copyOf(32)

private fun chacha(key: ByteArray, nonce: ByteArray, data: ByteArray, aad: ByteArray, enc: Boolean): ByteArray {
    val c = Cipher.getInstance("ChaCha20/Poly1305/NoPadding")
    c.init(if (enc) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE, SecretKeySpec(key, "ChaCha20"), IvParameterSpec(nonce))
    c.updateAAD(aad)
    return c.doFinal(data)
}
private fun nonce(c: Long) = ByteArray(12).also { for (i in 0 until 8) it[4 + i] = (c shr (8 * i)).toByte() }

private fun readExact(inp: InputStream, n: Int): ByteArray {
    val b = ByteArray(n); var o = 0
    while (o < n) { val r = inp.read(b, o, n - o); if (r < 0) throw EOFException("соединение закрыто"); o += r }
    return b
}

/** HAP-шифрование потока: блоки до 1024 байт, длина (2 байта LE) + шифртекст + тег. */
private class Hap(val wKey: ByteArray, val rKey: ByteArray) {
    private var w = 0L
    private var r = 0L
    fun enc(b: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(); var i = 0
        while (i < b.size) {
            val n = minOf(1024, b.size - i)
            val lb = byteArrayOf(n.toByte(), (n shr 8).toByte())
            o.write(lb); o.write(chacha(wKey, nonce(w++), b.copyOfRange(i, i + n), lb, true)); i += n
        }
        return o.toByteArray()
    }
    fun readFrame(inp: InputStream): ByteArray {
        val lb = readExact(inp, 2)
        val len = (lb[0].toInt() and 255) or ((lb[1].toInt() and 255) shl 8)
        return chacha(rKey, nonce(r++), readExact(inp, len + 16), lb, false)
    }
}

private const val RATE = 44100
private const val FRAMES = 352
private const val PKT = FRAMES * 4
private const val LATENCY = 22050 + RATE

private class Streamer(val host: String, val port: Int) : Closeable {
    private val sock = Socket()
    private lateinit var inp: InputStream
    private lateinit var out: OutputStream
    private var hap: Hap? = null
    private var cseq = 0
    private var plain = ByteArray(0)
    private val sessionId = SecureRandom().nextInt().toLong() and 0xFFFFFFFFL
    private val dacp = "%016X".format(SecureRandom().nextLong())
    private val closeables = mutableListOf<Closeable>()
    @Volatile private var alive = true
    @Volatile private var headTs = 0L
    private var startTs = 0L

    override fun close() {
        alive = false
        closeables.forEach { try { it.close() } catch (_: Exception) {} }
        try { sock.close() } catch (_: Exception) {}
        CaptureService.onPcm = null
    }

    // ---------- TLV8 ----------
    private fun tlv(vararg items: Pair<Int, ByteArray>): ByteArray {
        val o = ByteArrayOutputStream()
        for ((t, v) in items) {
            var i = 0
            while (i < v.size) { val n = minOf(255, v.size - i); o.write(t); o.write(n); o.write(v, i, n); i += n }
        }
        return o.toByteArray()
    }
    private fun parseTlv(b: ByteArray): Map<Int, ByteArray> {
        val m = LinkedHashMap<Int, ByteArray>(); var i = 0
        while (i + 1 < b.size) {
            val t = b[i].toInt() and 255; val n = b[i + 1].toInt() and 255
            m[t] = (m[t] ?: ByteArray(0)) + b.copyOfRange(i + 2, i + 2 + n); i += 2 + n
        }
        return m
    }

    // ---------- Крипто (SRP) ----------
    private fun h(vararg p: ByteArray): ByteArray {
        val d = MessageDigest.getInstance("SHA-512"); p.forEach { d.update(it) }; return d.digest()
    }
    private fun bytes(x: BigInteger): ByteArray {
        val b = x.toByteArray(); return if (b.size > 1 && b[0] == 0.toByte()) b.copyOfRange(1, b.size) else b
    }
    private fun pad(x: BigInteger): ByteArray { val b = bytes(x); return ByteArray(384 - b.size) + b }
    private fun xor(a: ByteArray, b: ByteArray) = ByteArray(a.size) { (a[it].toInt() xor b[it].toInt()).toByte() }
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    // ---------- RTSP ----------
    private fun fill() {
        val k = hap
        if (k == null) {
            val t = ByteArray(4096); val n = inp.read(t)
            if (n < 0) throw EOFException("соединение закрыто")
            plain += t.copyOf(n)
        } else plain += k.readFrame(inp)
    }

    @Synchronized
    private fun send(method: String, uri: String, headers: Map<String, String> = emptyMap(), body: ByteArray = ByteArray(0)): Pair<String, ByteArray> {
        val k = hap
        val sb = StringBuilder("$method $uri RTSP/1.0\r\nCSeq: ${cseq++}\r\n")
        if (k != null) {
            sb.append("DACP-ID: $dacp\r\nActive-Remote: ${sessionId}\r\nClient-Instance: $dacp\r\nUser-Agent: AirPlay/550.10\r\n")
        } else sb.append("User-Agent: AirPlay/320.20\r\n")
        headers.forEach { (a, b) -> sb.append("$a: $b\r\n") }
        sb.append("Content-Length: ${body.size}\r\n\r\n")
        val data = sb.toString().toByteArray() + body
        out.write(if (k == null) data else k.enc(data)); out.flush()

        var i: Int
        while (true) {
            i = String(plain, Charsets.ISO_8859_1).indexOf("\r\n\r\n")
            if (i >= 0) break
            fill()
        }
        val head = String(plain, 0, i, Charsets.ISO_8859_1)
        plain = plain.copyOfRange(i + 4, plain.size)
        val cl = Regex("(?i)content-length:\\s*(\\d+)").find(head)?.groupValues?.get(1)?.toInt() ?: 0
        while (plain.size < cl) fill()
        val resp = plain.copyOf(cl); plain = plain.copyOfRange(cl, plain.size)
        return head to resp
    }

    private fun ok(what: String, r: Pair<String, ByteArray>): Boolean {
        val line = r.first.lineSequence().first()
        if (!line.contains(" 200")) { Logger.log("$what — отказ:\n${r.first}\n${dump(r.second)}"); return false }
        Logger.log("$what: OK")
        return true
    }

    private fun dump(b: ByteArray): String = try {
        if (b.size > 6 && String(b, 0, 6) == "bplist") PropertyListParser.parse(b).toXMLPropertyList().take(1500)
        else String(b).take(600)
    } catch (e: Exception) { "не разобрать: $e (${b.size} байт)" }

    private val plistHdr = mapOf("Content-Type" to "application/x-apple-binary-plist")
    private fun plist(d: NSObject): ByteArray = BinaryPropertyListWriter.writeToArray(d)
    private fun uri() = "rtsp://${sock.localAddress.hostAddress}/$sessionId"

    // ---------- NTP ----------
    private fun ntpParts(): Pair<Int, Int> {
        val ms = System.currentTimeMillis()
        return (ms / 1000 + 2208988800L).toInt() to (((ms % 1000) shl 32) / 1000).toInt()
    }

    private fun startTiming(s: DatagramSocket) = Thread {
        val buf = ByteArray(128)
        try {
            while (alive) {
                val p = DatagramPacket(buf, buf.size); s.receive(p)
                if (p.length < 32) continue
                val (sec, frac) = ntpParts()
                val r = ByteBuffer.allocate(32)
                r.put(buf[0]); r.put(0xD3.toByte()); r.putShort(7); r.putInt(0)
                r.put(buf, 24, 8)
                r.putInt(sec).putInt(frac).putInt(sec).putInt(frac)
                s.send(DatagramPacket(r.array(), 32, p.address, p.port))
            }
        } catch (_: Exception) {}
    }.also { it.isDaemon = true; it.start() }

    private fun startSync(s: DatagramSocket, addr: InetAddress, ctrlPort: Int) = Thread {
        var first = true
        try {
            while (alive) {
                val ts = headTs
                val sec = (ts / RATE).toInt()
                val frac = (((ts % RATE) shl 32) / RATE).toInt()
                val rtp = ((ts - startTs + LATENCY) and 0xFFFFFFFFL).toInt()
                val b = ByteBuffer.allocate(20)
                b.put((if (first) 0x90 else 0x80).toByte()); b.put(0xD4.toByte()); b.putShort(7)
                b.putInt(rtp - LATENCY); b.putInt(sec); b.putInt(frac); b.putInt(rtp)
                s.send(DatagramPacket(b.array(), 20, addr, ctrlPort))
                first = false
                Thread.sleep(1000)
            }
        } catch (_: Exception) {}
    }.also { it.isDaemon = true; it.start() }

    private fun startEvents(kW: ByteArray, kR: ByteArray, evPort: Int) {
        var s: Socket? = null
        for (i in 0 until 5) {
            try { s = Socket().also { it.connect(InetSocketAddress(host, evPort), 3000) }; break }
            catch (_: Exception) { Thread.sleep(1000) }
        }
        val es = s ?: run { Logger.log("Канал событий не открылся (порт $evPort)"); return }
        closeables.add(es)
        val eh = Hap(kW, kR)
        Thread {
            try {
                val ins = es.getInputStream(); val os = es.getOutputStream()
                while (alive) {
                    val data = String(eh.readFrame(ins), Charsets.ISO_8859_1)
                    val proto = data.lineSequence().first().substringAfterLast(' ', "RTSP/1.0")
                    val cs = Regex("(?i)cseq:\\s*(\\d+)").find(data)?.groupValues?.get(1)
                    val resp = "$proto 200 OK\r\nContent-Length: 0\r\nAudio-Latency: 0\r\n" +
                        (if (cs != null) "CSeq: $cs\r\n" else "") + "\r\n"
                    synchronized(os) { os.write(eh.enc(resp.toByteArray())); os.flush() }
                }
            } catch (_: Exception) {}
        }.also { it.isDaemon = true; it.start() }
    }

    // ---------- Сценарий ----------
    fun go(stopFn: () -> Boolean) {
        sock.connect(InetSocketAddress(host, port), 5000)
        sock.soTimeout = 10000
        inp = sock.getInputStream(); out = sock.getOutputStream()
        val addr = InetAddress.getByName(host)
        val hdr = mapOf("Content-Type" to "application/octet-stream", "X-Apple-HKP" to "4")

        // ----- Pair-setup (transient) -----
        Logger.log("Сопряжение…")
        var r = send("POST", "/pair-setup", hdr, tlv(0 to byteArrayOf(0), 6 to byteArrayOf(1), 0x13 to byteArrayOf(0x10)))
        if (!ok("pair-setup 1", r)) return
        val t2 = parseTlv(r.second)
        t2[7]?.let { Logger.log("Ошибка TLV: ${hex(it)}"); return }
        val salt = t2[2] ?: run { Logger.log("Нет salt"); return }
        val bBytes = t2[3] ?: run { Logger.log("Нет публичного ключа"); return }

        val grp = SRP6StandardGroups.rfc5054_3072
        val n = grp.n; val g = grp.g
        val k = BigInteger(1, h(bytes(n), pad(g)))
        val a = BigInteger(1, ByteArray(64).also { SecureRandom().nextBytes(it) })
        val bigA = g.modPow(a, n)
        val x = BigInteger(1, h(salt, h("Pair-Setup:3939".toByteArray())))
        val bigB = BigInteger(1, bBytes)
        val u = BigInteger(1, h(pad(bigA), pad(bigB)))
        val s = bigB.subtract(k.multiply(g.modPow(x, n))).mod(n).modPow(a.add(u.multiply(x)), n)
        val kSess = h(bytes(s))
        val m1 = h(xor(h(bytes(n)), h(bytes(g))), h("Pair-Setup".toByteArray()), salt, bytes(bigA), bytes(bigB), kSess)

        r = send("POST", "/pair-setup", hdr, tlv(6 to byteArrayOf(3), 3 to pad(bigA), 4 to m1))
        if (!ok("pair-setup 3", r)) return
        val t4 = parseTlv(r.second)
        t4[7]?.let { Logger.log("Колонка отклонила доказательство: ${hex(it)}"); return }
        val m2 = t4[4] ?: run { Logger.log("Нет proof"); return }
        if (!m2.contentEquals(h(bytes(bigA), m1, kSess))) { Logger.log("Proof колонки не совпал"); return }

        hap = Hap(hkdf(kSess, "Control-Salt", "Control-Write-Encryption-Key"),
            hkdf(kSess, "Control-Salt", "Control-Read-Encryption-Key"))
        Logger.log("Канал зашифрован")

        // ----- SETUP 1 -----
        val timing = DatagramSocket(0); closeables.add(timing)
        val control = DatagramSocket(0); closeables.add(control)
        startTiming(timing)

        val d1 = NSDictionary()
        d1.put("deviceID", NSString("AA:BB:CC:DD:EE:FF"))
        d1.put("macAddress", NSString("AA:BB:CC:DD:EE:FF"))
        d1.put("sessionUUID", NSString(java.util.UUID.randomUUID().toString().uppercase()))
        d1.put("timingProtocol", NSString("NTP"))
        d1.put("timingPort", NSNumber(timing.localPort))
        d1.put("isMultiSelectAirPlay", NSNumber(true))
        d1.put("groupContainsGroupLeader", NSNumber(false))
        d1.put("senderSupportsRelay", NSNumber(false))
        d1.put("statsCollectionEnabled", NSNumber(false))
        d1.put("model", NSString("iPhone14,3"))
        d1.put("name", NSString("HomePodCast"))
        d1.put("osName", NSString("iPhone OS"))
        d1.put("osVersion", NSString("16.5"))
        d1.put("osBuildVersion", NSString("20F66"))
        d1.put("sourceVersion", NSString("690.7.1"))
        r = send("SETUP", uri(), plistHdr, plist(d1))
        if (!ok("SETUP 1", r)) return
        val resp1 = PropertyListParser.parse(r.second) as NSDictionary
        val evPort = (resp1.objectForKey("eventPort") as? NSNumber)?.intValue() ?: 0
        Logger.log("eventPort=$evPort")

        val evW = hkdf(kSess, "Events-Salt", "Events-Write-Encryption-Key")
        val evR = hkdf(kSess, "Events-Salt", "Events-Read-Encryption-Key")
        if (evPort != 0) startEvents(evW, evR, evPort)

        // ----- SETUP 2 (аудиопоток) -----
        val shk = evW
        val st = NSDictionary()
        st.put("audioFormat", NSNumber(0x800))
        st.put("audioMode", NSString("default"))
        st.put("controlPort", NSNumber(control.localPort))
        st.put("ct", NSNumber(1))
        st.put("isMedia", NSNumber(true))
        st.put("latencyMax", NSNumber(88200))
        st.put("latencyMin", NSNumber(11025))
        st.put("shk", NSData(shk))
        st.put("spf", NSNumber(FRAMES))
        st.put("sr", NSNumber(RATE))
        st.put("type", NSNumber(0x60))
        st.put("supportsDynamicStreamID", NSNumber(false))
        st.put("streamConnectionID", NSNumber(sessionId))
        val d2 = NSDictionary()
        d2.put("streams", NSArray(st))
        r = send("SETUP", uri(), plistHdr, plist(d2))
        if (!ok("SETUP 2", r)) return
        val stream = ((PropertyListParser.parse(r.second) as NSDictionary).objectForKey("streams") as NSArray).objectAtIndex(0) as NSDictionary
        val ctrlPort = (stream.objectForKey("controlPort") as NSNumber).intValue()
        val dataPort = (stream.objectForKey("dataPort") as NSNumber).intValue()
        Logger.log("dataPort=$dataPort controlPort=$ctrlPort")

        // ----- Источник звука -----
        val live = CaptureService.active
        val feed = LinkedBlockingQueue<ByteArray>(200)
        if (live) CaptureService.onPcm = { b, len -> feed.offer(b.copyOf(len)) }
        Logger.log(if (live) "Источник: звук телефона" else "Источник: тестовый тон 440 Гц, 5 секунд")

        // ----- Состояние потока -----
        val (nsec, nfrac) = ntpParts()
        startTs = (nsec.toLong() and 0xFFFFFFFFL) * RATE + (((nfrac.toLong() and 0xFFFFFFFFL) * RATE) ushr 32)
        headTs = startTs
        var seq = SecureRandom().nextInt(65536)
        startSync(control, addr, ctrlPort)

        r = send("RECORD", uri())
        if (!ok("RECORD", r)) return
        r = send("FLUSH", uri(), mapOf("Range" to "npt=0-", "Session" to "0",
            "RTP-Info" to "seq=$seq;rtptime=${(headTs - startTs + LATENCY) and 0xFFFFFFFFL}"))
        ok("FLUSH", r)

        val fb = Thread {
            try { while (alive) { Thread.sleep(2000); send("POST", "/feedback") } } catch (_: Exception) {}
        }.also { it.isDaemon = true; it.start() }

        // ----- Отправка аудио -----
        val audio = DatagramSocket(); closeables.add(audio)
        val acc = ByteArrayOutputStream()
        var counter = 0L
        var frames = 0L
        var phase = 0.0
        val t0 = System.nanoTime()
        var first = true
        Logger.log("Играю…")
        while (!stopFn()) {
            val pcm = ByteArray(PKT)
            if (live) {
                if (!CaptureService.active) break
                val chunk = feed.poll(500, TimeUnit.MILLISECONDS) ?: continue
                acc.write(chunk)
                if (acc.size() < PKT) continue
                val all = acc.toByteArray()
                System.arraycopy(all, 0, pcm, 0, PKT)
                acc.reset(); acc.write(all, PKT, all.size - PKT)
                var i = 0   // Android даёт little-endian, AirPlay ждёт big-endian
                while (i < PKT) { val t = pcm[i]; pcm[i] = pcm[i + 1]; pcm[i + 1] = t; i += 2 }
            } else {
                if (frames >= 5L * RATE) break
                for (f in 0 until FRAMES) {
                    val v = (sin(phase) * 8000).toInt(); phase += 2 * PI * 440 / RATE
                    for (c in 0..1) { pcm[f * 4 + c * 2] = (v shr 8).toByte(); pcm[f * 4 + c * 2 + 1] = v.toByte() }
                }
            }

            val rtp = ((headTs - startTs + LATENCY) and 0xFFFFFFFFL).toInt()
            val header = ByteBuffer.allocate(12)
            header.put(0x80.toByte()); header.put((if (first) 0xE0 else 0x60).toByte())
            header.putShort(seq.toShort()); header.putInt(rtp); header.putInt(sessionId.toInt())
            val hb = header.array()
            val nc = nonce(counter++)
            val ct = chacha(shk, nc, pcm, hb.copyOfRange(4, 12), true)
            val pkt = hb + ct + nc.copyOfRange(4, 12)
            audio.send(DatagramPacket(pkt, pkt.size, addr, dataPort))

            first = false
            seq = (seq + 1) and 0xFFFF
            headTs += FRAMES
            frames += FRAMES

            if (!live) {   // темп для тестового тона
                val ahead = frames * 1_000_000_000L / RATE - (System.nanoTime() - t0)
                if (ahead > 0) Thread.sleep(ahead / 1_000_000, (ahead % 1_000_000).toInt())
            }
        }
        if (!live) Thread.sleep(2500)   // дать колонке доиграть буфер

        alive = false
        fb.interrupt()
        try { fb.join(1500) } catch (_: Exception) {}
        try { send("TEARDOWN", uri(), mapOf("Session" to "0")) } catch (_: Exception) {}
    }
}
