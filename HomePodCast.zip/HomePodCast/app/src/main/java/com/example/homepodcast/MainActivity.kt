package com.example.homepodcast

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var nsd: NsdManager
    private lateinit var logView: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val devices = mutableListOf<NsdServiceInfo>()
    private var selected: NsdServiceInfo? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var discovering = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        nsd = getSystemService(Context.NSD_SERVICE) as NsdManager

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }

        btn("1. Найти HomePod") { scan() }
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, mutableListOf<String>())
        list.adapter = adapter
        list.choiceMode = ListView.CHOICE_MODE_SINGLE
        list.setOnItemClickListener { _, _, pos, _ -> selected = devices[pos]; Logger.log("Выбрано: ${adapter.getItem(pos)}") }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        btn("2. Проверить связь (RTSP OPTIONS)") {
            val s = selected
            if (s == null) Logger.log("Сначала выберите колонку") else RaopProbe.run(s.host.hostAddress!!, s.port)
        }
        btn("3. Старт захвата звука") { startCapture() }
        btn("Стоп") { startService(Intent(this, CaptureService::class.java).setAction("STOP")) }

        logView = TextView(this).apply { textSize = 11f; gravity = Gravity.BOTTOM }
        val sv = ScrollView(this).apply { addView(logView) }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1.3f))
        setContentView(root)

        Logger.sink = { m -> logView.append(m + "\n"); sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) } }
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun label(i: NsdServiceInfo): String {
        val model = i.attributes["am"]?.toString(Charsets.UTF_8) ?: "?"
        return "${i.serviceName.substringAfter('@')} [$model] ${i.host?.hostAddress}:${i.port}"
    }

    private fun scan() {
        if (discovering) return
        discovering = true
        devices.clear(); adapter.clear()
        Logger.log("Поиск _raop._tcp ...")
        nsd.discoverServices("_raop._tcp", NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(i: NsdServiceInfo) { synchronized(queue) { queue.add(i) }; next() }
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onDiscoveryStopped(t: String) { discovering = false }
            override fun onStartDiscoveryFailed(t: String, e: Int) { discovering = false; Logger.log("Ошибка поиска: $e") }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        })
    }

    @Synchronized private fun next() {
        if (resolving) return
        val s = synchronized(queue) { queue.removeFirstOrNull() } ?: return
        resolving = true
        nsd.resolveService(s, object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, e: Int) { resolving = false; next() }
            override fun onServiceResolved(i: NsdServiceInfo) {
                resolving = false
                runOnUiThread { devices.add(i); adapter.add(label(i)) }
                next()
            }
        })
    }

    private fun startCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 100 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data))
        } else if (req == 100) Logger.log("Доступ к захвату не выдан")
    }

    override fun onDestroy() { Logger.sink = null; super.onDestroy() }
}
