package com.example.homepodcast

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0A0A0A")
    private val LINE = Color.parseColor("#1F1F1F")
    private val DIM = Color.parseColor("#8A8A8A")
    private val CHIP = Color.parseColor("#161616")
    private val PILL = Color.parseColor("#E6E6E6")

    private lateinit var nsd: NsdManager
    private lateinit var listBox: LinearLayout
    private lateinit var countChip: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var mainBtn: TextView

    private val devices = mutableListOf<NsdServiceInfo>()
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var discovering = false
    private var restart = false
    private var listener: NsdManager.DiscoveryListener? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        nsd = getSystemService(Context.NSD_SERVICE) as NsdManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            setPadding(dp(20), dp(16), dp(20), dp(20))
        }

        // Шапка
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(tv("HomePodCast", 26f, bold = true).apply { letterSpacing = -0.03f },
            LinearLayout.LayoutParams(0, -2, 1f))
        val pill = LinearLayout(this).apply { background = shape(Color.BLACK, 28, LINE); gravity = Gravity.CENTER_VERTICAL }
        fun iconBtn(t: String, f: () -> Unit) = tv(t, 22f).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { f() }
        }
        pill.addView(iconBtn("↻") { scan() })
        pill.addView(iconBtn("⋯") {
            logScroll.visibility = if (logScroll.visibility == View.GONE) View.VISIBLE else View.GONE
        })
        header.addView(pill)
        root.addView(header)

        // Заголовок раздела
        val sec = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sec.addView(tv("Devices", 30f, bold = true).apply { letterSpacing = -0.03f },
            LinearLayout.LayoutParams(0, -2, 1f))
        countChip = tv("0 devices", 13f, DIM, true).apply {
            background = shape(CHIP, 16); setPadding(dp(14), dp(7), dp(14), dp(7))
        }
        sec.addView(countChip)
        root.addView(sec, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28); bottomMargin = dp(16) })

        // Список колонок
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))

        // Лог (скрыт, открывается кнопкой ⋯)
        logView = tv("", 11f, DIM).apply { setPadding(dp(14), dp(10), dp(14), dp(10)); setTextIsSelectable(true) }
        logScroll = ScrollView(this).apply {
            addView(logView); visibility = View.GONE; background = shape(Color.BLACK, 20, LINE)
        }
        root.addView(logScroll, LinearLayout.LayoutParams(-1, dp(160)).apply { bottomMargin = dp(14) })

        // Главная кнопка
        mainBtn = tv("", 17f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER; background = shape(PILL, 32)
            setOnClickListener {
                if (CaptureService.active) startService(Intent(this@MainActivity, CaptureService::class.java).setAction("STOP"))
                else startCapture()
            }
        }
        root.addView(mainBtn, LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(root)

        Logger.sink = { m ->
            logView.append(m + "\n"); logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }; updateBtn()
        }
        updateBtn(); render()
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        scan()
    }

    override fun onResume() { super.onResume(); updateBtn() }

    private fun updateBtn() {
        mainBtn.text = if (CaptureService.active) "■  Stop capture" else "▶  Start capture"
    }

    // ---------- UI списка ----------
    private fun name(d: NsdServiceInfo) = d.serviceName.substringAfter('@')
    private fun model(d: NsdServiceInfo): String {
        val m = d.attributes["am"]?.toString(Charsets.UTF_8) ?: return "AirPlay"
        return when {
            m.startsWith("AudioAccessory") -> "HomePod"
            m.startsWith("AppleTV") -> "Apple TV"
            else -> m
        }
    }

    private fun render() {
        listBox.removeAllViews()
        countChip.text = "${devices.size} device" + if (devices.size == 1) "" else "s"
        if (devices.isEmpty()) {
            listBox.addView(tv("Ищу колонки в сети…", 15f, DIM).apply { setPadding(dp(6), dp(20), 0, 0) })
            return
        }
        devices.forEach { listBox.addView(card(it), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }) }
    }

    private fun card(d: NsdServiceInfo): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = shape(Color.BLACK, 28, LINE)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv("◉", 24f).apply { gravity = Gravity.CENTER; background = shape(CHIP, 20) },
            LinearLayout.LayoutParams(dp(56), dp(56)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        names.addView(tv(name(d), 20f, bold = true))
        names.addView(tv(model(d), 15f, DIM))
        top.addView(names)
        c.addView(top)
        val cast = tv("Cast", 16f, bold = true).apply {
            gravity = Gravity.CENTER; background = shape(CHIP, 24, LINE)
            setPadding(dp(34), dp(13), dp(34), dp(13))
            setOnClickListener {
                if (RaopProbe.running) { RaopProbe.stop(); text = "Cast"; return@setOnClickListener }
                logScroll.visibility = View.VISIBLE
                Logger.log("Cast → ${name(d)} (${d.host?.hostAddress}:${d.port})")
                text = "Stop"
                val self = this
                RaopProbe.run(d.host.hostAddress!!, d.port) { runOnUiThread { self.text = "Cast" } }
            }
        }
        c.addView(cast, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END; topMargin = dp(10) })
        return c
    }

    // ---------- Поиск ----------
    private fun scan() {
        if (discovering) {
            restart = true
            try { nsd.stopServiceDiscovery(listener) } catch (_: Exception) { discovering = false; restart = false }
            if (!discovering) scan()
            return
        }
        discovering = true
        devices.clear(); synchronized(queue) { queue.clear() }; render()
        listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(i: NsdServiceInfo) { synchronized(queue) { queue.add(i) }; next() }
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onDiscoveryStopped(t: String) {
                discovering = false
                if (restart) { restart = false; runOnUiThread { scan() } }
            }
            override fun onStartDiscoveryFailed(t: String, e: Int) { discovering = false; Logger.log("Ошибка поиска: $e") }
            override fun onStopDiscoveryFailed(t: String, e: Int) { discovering = false }
        }
        nsd.discoverServices("_raop._tcp", NsdManager.PROTOCOL_DNS_SD, listener)
    }

    @Synchronized private fun next() {
        if (resolving) return
        val s = synchronized(queue) { queue.removeFirstOrNull() } ?: return
        resolving = true
        nsd.resolveService(s, object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, e: Int) { resolving = false; next() }
            override fun onServiceResolved(i: NsdServiceInfo) {
                resolving = false
                runOnUiThread { if (devices.none { it.serviceName == i.serviceName }) { devices.add(i); render() } }
                next()
            }
        })
    }

    // ---------- Захват ----------
    private fun startCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 100 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data))
        } else if (req == 100) Logger.log("Доступ к захвату не выдан")
    }

    override fun onDestroy() { Logger.sink = null; super.onDestroy() }
}
