package com.example.homepodcast

import java.net.InetSocketAddress
import java.net.Socket

/** Проверка связи: шлёт RTSP OPTIONS и пишет ответ колонки в лог. */
object RaopProbe {
    fun run(host: String, port: Int) {
        Thread {
            try {
                Logger.log("Подключаюсь к $host:$port ...")
                Socket().use { s ->
                    s.connect(InetSocketAddress(host, port), 5000)
                    s.soTimeout = 5000
                    val req = "OPTIONS * RTSP/1.0\r\n" +
                        "CSeq: 1\r\n" +
                        "User-Agent: HomePodCast/0.1\r\n" +
                        "Client-Instance: 0123456789ABCDEF\r\n\r\n"
                    s.getOutputStream().write(req.toByteArray())
                    val buf = ByteArray(4096)
                    val n = s.getInputStream().read(buf)
                    Logger.log("Ответ ($n байт):\n" + (if (n > 0) String(buf, 0, n) else "пусто"))
                }
            } catch (e: Exception) {
                Logger.log("Ошибка зонда: $e")
            }
        }.start()
    }
}
